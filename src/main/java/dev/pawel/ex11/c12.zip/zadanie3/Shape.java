package dev.pawel.ex11.zadanie3;

public class Shape {
    public double area() {
        return 0.0;
    }
}

package dev.pawel.ex11.zadanie2;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog("black");
        dog.makeSound();
        dog.run();
        dog.bark();
    }
}

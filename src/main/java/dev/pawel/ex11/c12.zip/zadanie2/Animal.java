package dev.pawel.ex11.zadanie2;

public class Animal {
    public void makeSound() {
        System.out.println("Animal makes a sound");
    }
}

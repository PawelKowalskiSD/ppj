package dev.pawel.ex11.zadanie1;

public class Main {
    public static void main(String[] args) {
        Welder welder = new Welder("Damiano", "22");
        welder.display();
    }
}

package dev.pawel.ex09.zadanie3;

public class Main {
    public static void main(String[] args) {
        Fruit fruit = new Fruit("Orange");
        System.out.println(fruit);
    }
}

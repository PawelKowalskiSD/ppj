package dev.pawel.ex09.zadanie1;

public class Person {
    String name;
    String surname;
    int age;
}

package dev.pawel.ex09.zadanie7;

public class Main {
}

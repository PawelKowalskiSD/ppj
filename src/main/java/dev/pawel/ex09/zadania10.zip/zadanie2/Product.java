package dev.pawel.ex09.zadanie2;

public record Product(String productName, double price, int stock){
}

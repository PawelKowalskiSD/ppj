package dev.pawel.ex08;

public class Zadanie1 {
    public static void main(String[] args) {
        show(15);
    }

    public static void show(int num) {
        System.out.println(num);
    }
}

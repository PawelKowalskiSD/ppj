package dev.pawel.ex10.zadanie1;

public class Main {
    public static void main(String[] args) {
        System.out.println(AreaCalculator.calculateArea(5));
        System.out.println(AreaCalculator.calculateArea(4, 6));
        System.out.println(AreaCalculator.calculateArea(3.0));
    }
}
